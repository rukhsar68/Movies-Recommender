

my_file=open("movies.csv","r",encoding="utf8")
titles=my_file.readline()

def main():
    f=open("data.txt","w+")
  
    for i in range(9740):     
     content=my_file.readline()
     columns=content.split(',')
     #j=2
     #for j in columns:       
     #print(columns)   
      #f.write(1)
     f.write("\n") 
     f.write(str(i))
     f.write(",")
   
     f.write(columns[1])
    
     genre=columns[2]
     
     types=columns[2].split('|')
     
     print(types)
     
     
     #j=types.index
     #print(j)
     #for s in range(j):
     if  "Action" in types:
       f.write(',1')
     else:
       f.write(',0')  
     if "Adventure" in types:
        f.write(',1')
     else:
        f.write(',0')

     if "Children" in types:
        f.write(',1')
     else:
        f.write(',0')

     if "Crime" in types:
        f.write(',1')
     else:
        f.write(',0')

     if "Thriller" in types:
        f.write(',1')
     else:
        f.write(',0')

     if "Romance" in types:
        f.write(',1')
     else:
        f.write(',0')


     if "Comedy" in types:
        f.write(',1')
     else:
      f.write(',0')


     if "Horror" in types:
        f.write(',1')
     else:
        f.write(',0')

     if "Animation" in types:
        f.write(',1')
     else:
        f.write(',0')

     if "Fantasy" in types:
        f.write(',1')  
     else:
        f.write(',0')


     if "Drama" in types:
        f.write(',1')  
     else:
        f.write(',0')


   
     if "Mystery" in types:
        f.write(',1')  
     else:
        f.write(',0')


    
     if "Sci-Fi" in types:
        f.write(',1')  
     else:
        f.write(',0')
    
     if "War" in types:
        f.write(',1')  
     else:
        f.write(',0') 
     if "Musical" in types:
        f.write(',1')  
     else:
        f.write(',0')

    
     if "Drama" in types:
        f.write(',1')  
     else:
        f.write(',0')
     
     if "Documentary" in types:
        f.write(',1')  
     else:
        f.write(',0')      
    f.close

if __name__=="__main__":
    main()
