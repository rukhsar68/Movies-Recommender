from flask import Flask, render_template , request
import pandas
import operator
import math


file_data=pandas.read_csv('data.csv')
data=file_data.values.tolist()#covert into list
app= Flask(__name__)

@app.route('/')
def home():
    return render_template("areej.html" , name="None" , catagor="None")
@app.route('/movie', methods = ['POST','GET'])
def movie():
    movie=request.form.to_dict()
    
    movie['index']=findMovie(movie['Name'])#name of search movie                                                                                                                            
    if movie['index']==-1:
        return render_template("areej.html" , name="Movie does not exist" , catagory="None")  
    movie['catagory']=getCatagory(movie['index'])
   
    indeces=KNN(movie['index'])
    
    suggestions=[]
    
    for j in indeces:
        #print(j)
        s=[]
        s.append(data[j][1])
        
        s.append(getCatagory(j))
        suggestions.append(s)
    return render_template("areej.html" , name=movie['Name'] , catagory=movie['catagory'] , suggestions=suggestions)

def getCatagory(index):
    catagory=""
    for i in range (2 , len(file_data.columns)):
        if data[index][i]==1:
            catagory=catagory + " | " + file_data.columns[i]
            
    return catagory
    

def findMovie(name):
    i=0
    for row in data:
        if row[1]==name:
            return i
        i=i+1
    return -1    

def KNN(index):
    distance = []
    
    sIndeces=  []
    for i in range (0, len(file_data)):
        sum = 0
        for j in range(2, len(file_data.columns)):
            sum = sum + ((data[i][j]-data[index][j])**2)   
        dist = math.sqrt(sum)   
        distance.append((i,dist))
     
    distance.pop(index)
    distance.sort(key = lambda x: x[1])
    for k in range (0,5):
        sIndeces.append(distance[k][0]) 
    return sIndeces

if __name__ == "__main__":
    app.run()
